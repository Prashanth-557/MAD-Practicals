package com.example.exercise7;

public class Required {
}
