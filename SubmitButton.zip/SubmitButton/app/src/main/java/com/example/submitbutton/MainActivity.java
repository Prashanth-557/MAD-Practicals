package com.example.submitbutton;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etName, etAge, etDepartment;
    private TextView tvDisplay;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        etDepartment = findViewById(R.id.etDepartment);
        btnSubmit = findViewById(R.id.btnSubmit);
        tvDisplay = findViewById(R.id.tvDisplay);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String age = etAge.getText().toString();
                String department = etDepartment.getText().toString();

                String displayText = "Name: " + name + "\nAge: " + age + "\nDepartment: " + department;
                tvDisplay.setText(displayText);
            }
        });
    }
}

