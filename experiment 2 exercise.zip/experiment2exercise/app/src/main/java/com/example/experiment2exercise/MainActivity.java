package com.example.experiment2exercise;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    EditText etName, etEmail, etPhone;
    Spinner spinnerGender;
    RadioGroup rgCourse;
    CheckBox cbTerms;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        spinnerGender = findViewById(R.id.spinnerGender);
        rgCourse = findViewById(R.id.rgCourse);
        cbTerms = findViewById(R.id.cbTerms);
        btnSubmit = findViewById(R.id.btnSubmit);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.gender_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGender.setAdapter(adapter);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String email = etEmail.getText().toString();
                String phone = etPhone.getText().toString();
                String gender = spinnerGender.getSelectedItem().toString();
                int selectedCourseId = rgCourse.getCheckedRadioButtonId();
                RadioButton selectedCourse = findViewById(selectedCourseId);
                String course = selectedCourse.getText().toString();
                boolean termsAccepted = cbTerms.isChecked();
                if (!termsAccepted) {
                    Toast.makeText(MainActivity.this, "Please accept the Terms and Conditions.", Toast.LENGTH_SHORT).show();
                } else {
                    String message = "Name: " + name + "\nEmail: " + email + "\nPhone: " + phone +
                            "\nGender: " + gender + "\nCourse: " + course;
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}

