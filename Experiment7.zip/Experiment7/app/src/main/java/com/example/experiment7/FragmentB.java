package com.example.experiment7;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentB extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for FragmentB
        View view = inflater.inflate(R.layout.fragment_b, container, false);

        // Get reference to the TextView in FragmentB
        TextView displayText = view.findViewById(R.id.displayTextB);

        // Retrieve the input text passed from FragmentA
        if (getArguments() != null) {
            String inputText = getArguments().getString("inputText", "No input received");
            displayText.setText(inputText); // Display the text in FragmentB
        }

        // Button to return to FragmentA
        Button button = view.findViewById(R.id.buttonToFragmentA);
        button.setOnClickListener(v -> {
            // Pop the current fragment from the back stack to return to FragmentA
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        return view;
    }
}
