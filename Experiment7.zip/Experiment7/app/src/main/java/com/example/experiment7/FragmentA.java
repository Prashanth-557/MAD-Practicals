package com.example.experiment7;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentA extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for FragmentA
        View view = inflater.inflate(R.layout.fragment_a, container, false);

        // Get references to the EditText and Button in FragmentA
        EditText editText = view.findViewById(R.id.editTextA);
        Button button = view.findViewById(R.id.buttonToFragmentB);

        // Set an OnClickListener to the button
        button.setOnClickListener(v -> {
            String inputText = editText.getText().toString();

            // Create FragmentB and pass the inputText through a Bundle
            FragmentB fragmentB = new FragmentB();
            Bundle bundle = new Bundle();
            bundle.putString("inputText", inputText); // Pass data
            fragmentB.setArguments(bundle);

            // Replace FragmentA with FragmentB
            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainer, fragmentB) // Correct the method name
                    .addToBackStack(null)
                    .commit();
        });

        return view;
    }
}
