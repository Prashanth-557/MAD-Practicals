package com.example.experiment66;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    private EditText editTextName;
    private Button buttonOk;
    private TextView textViewGreeting;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextName = findViewById(R.id.editTextName);
        buttonOk = findViewById(R.id.buttonOk);
        textViewGreeting = findViewById(R.id.textViewGreeting);
        buttonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                String greeting = "Hello, " + name + "!";
                textViewGreeting.setText(greeting);
            }
        });
    }
}
