package com.example.bus_booking;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPhone, etPassport, etDate, etTime;
    private Spinner spinnerDestination;
    private RadioGroup radioGroupGender;
    private CheckBox cbWindowSeat, cbExtraLuggage, cbMeal;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etPassport = findViewById(R.id.etPassport);
        etDate = findViewById(R.id.etDate);
        etTime = findViewById(R.id.etTime);
        spinnerDestination = findViewById(R.id.spinnerDestination);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        cbWindowSeat = findViewById(R.id.cbWindowSeat);
        cbExtraLuggage = findViewById(R.id.cbExtraLuggage);
        cbMeal = findViewById(R.id.cbMeal);
        btnSubmit = findViewById(R.id.btnSubmit);

        // Populate Spinner
        String[] destinations = {"Hyderabad", "Sangareddy", "Ongole", "Vizag", "Nizambad"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, destinations);
        spinnerDestination.setAdapter(adapter);

        // Date Picker
        etDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) ->
                            etDate.setText(selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear),
                    year, month, day);
            datePickerDialog.show();
        });

        // Time Picker
        etTime.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this,
                    (view, selectedHour, selectedMinute) ->
                            etTime.setText(selectedHour + ":" + String.format("%02d", selectedMinute)),
                    hour, minute, true);
            timePickerDialog.show();
        });

        // Handle button click
        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();
            String phone = etPhone.getText().toString();
            String passport = etPassport.getText().toString();
            String destination = spinnerDestination.getSelectedItem().toString();
            String date = etDate.getText().toString();
            String time = etTime.getText().toString();

            // Get selected gender
            int selectedGenderId = radioGroupGender.getCheckedRadioButtonId();
            RadioButton selectedGender = findViewById(selectedGenderId);
            String gender = selectedGender != null ? selectedGender.getText().toString() : "Not Selected";

            // Get checkbox selections
            StringBuilder preferences = new StringBuilder();
            if (cbWindowSeat.isChecked()) preferences.append("Window Seat, ");
            if (cbExtraLuggage.isChecked()) preferences.append("Extra Luggage, ");
            if (cbMeal.isChecked()) preferences.append("Meal Preference, ");

            // Remove last comma if any
            if (preferences.length() > 0) {
                preferences.setLength(preferences.length() - 2);
            }

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || passport.isEmpty() ||
                    date.isEmpty() || time.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please fill all fields",
                        Toast.LENGTH_SHORT).show();
            } else {
                String message = "Booking Confirmed!\n"
                        + "Name: " + name + "\n"
                        + "Gender: " + gender + "\n"
                        + "Destination: " + destination + "\n"
                        + "Date: " + date + " at " + time + "\n"
                        + "Preferences: " + (preferences.length() > 0 ? preferences.toString() : "None");

                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }
}

